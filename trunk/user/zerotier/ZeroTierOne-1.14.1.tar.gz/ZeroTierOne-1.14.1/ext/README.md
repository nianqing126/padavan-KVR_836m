Miscellaneous Stuff
======

This subfolder contains:

 * Bundled third party libraries that are compiled into the binary on platforms and Linux distributions where they are not available on the system.

 * Pre-compiled binaries for some platforms, such as pre-built and signed drivers for Mac and Windows.

 * Miscellaneous files used by installers and packages on various platform targets.
